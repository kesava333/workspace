# light-weight-aws-deployment

The goal for this project is to create a minimal docker image that will automate the deployment of an AWS system from beginning to end. 

## Getting started

## prerequisites

* Docker or Podman installed 
   * Docker can be installed using this link: [Install Docker](https://docs.docker.com/engine/install/ubuntu/)
   * Podman can be installed using this link: [Install Podman](https://podman.io/getting-started/installation)
* AWS credentails 



First you need to make sure you have an .aws folder with your credentials and config file. It should be located at ~/.aws/

here is what your .aws/config file should look like:
``` 
[default]
region=us-east-2
output=json
```
and your credentials file should be like this:
```
[default]
aws_access_key_id=******************************
aws_secret_access_key=**************************
```

Now cd into `~/.aws/` and clone the repository:
``` 
git clone https://gitlab.clearpathrobotics.com/kginjupalli/light-weight-aws-deployment.git 
```
Now cd into `light-weight-aws-deployment` 

Make `create_container` file executable by running this command
```
chmod +x create_container
```

Then excute the file by running `./create_container`. This will create Docker image by installing all necessary depedencies

It will create a conatiner and shell's you in as a `root` user

Now, execute the file called `deploy` using 
```
./deploy
```


P.S if you don't have your .aws credentials/config files when running the Dockerfile, you can choose to mount your .aws folder when you create your container. Once you mount it you can run the `deploy` bash script to start simulation creation and setup.
